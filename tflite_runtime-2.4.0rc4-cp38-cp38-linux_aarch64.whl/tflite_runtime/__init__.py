__version__ = '2.4.0rc4'
__git_version__ = '0.6.0-98275-g97c3fef64ba'
